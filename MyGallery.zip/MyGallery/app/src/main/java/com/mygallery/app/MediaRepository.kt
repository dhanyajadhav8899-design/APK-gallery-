package com.mygallery.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val mime: String,
    val timeMillis: Long,
    val size: Long,
    val width: Int,
    val height: Int,
    val isVideo: Boolean,
    val durationMs: Long,
    val bucketId: Long,
    val bucketName: String
)

data class Album(
    val bucketId: Long,
    val name: String,
    val cover: MediaItem,
    val count: Int
)

object MediaRepository {

    fun loadAll(context: Context): List<MediaItem> {
        val out = ArrayList<MediaItem>()
        out += query(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false)
        out += query(context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
        out.sortByDescending { it.timeMillis }
        return out
    }

    private fun query(context: Context, base: Uri, video: Boolean): List<MediaItem> {
        val list = ArrayList<MediaItem>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.WIDTH,
            MediaStore.MediaColumns.HEIGHT,
            MediaStore.Images.ImageColumns.DATE_TAKEN,
            MediaStore.Images.ImageColumns.BUCKET_ID,
            MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME,
            if (video) MediaStore.Video.VideoColumns.DURATION else MediaStore.MediaColumns._ID
        )
        context.contentResolver.query(base, projection, null, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iW = c.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH)
            val iH = c.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT)
            val iTaken = c.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATE_TAKEN)
            val iBid = c.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.BUCKET_ID)
            val iBname = c.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.BUCKET_DISPLAY_NAME)
            val iDur = if (video) c.getColumnIndexOrThrow(MediaStore.Video.VideoColumns.DURATION) else -1
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val taken = c.getLong(iTaken)
                val time = if (taken > 0) taken else c.getLong(iAdded) * 1000L
                list += MediaItem(
                    id = id,
                    uri = ContentUris.withAppendedId(base, id),
                    name = c.getString(iName) ?: "",
                    mime = c.getString(iMime) ?: "",
                    timeMillis = time,
                    size = c.getLong(iSize),
                    width = c.getInt(iW),
                    height = c.getInt(iH),
                    isVideo = video,
                    durationMs = if (iDur >= 0) c.getLong(iDur) else 0L,
                    bucketId = c.getLong(iBid),
                    bucketName = c.getString(iBname) ?: "Other"
                )
            }
        }
        return list
    }

    fun albums(items: List<MediaItem>): List<Album> =
        items.groupBy { it.bucketId }
            .map { (bid, list) -> Album(bid, list.first().bucketName, list.first(), list.size) }
            .sortedByDescending { it.cover.timeMillis }
}
