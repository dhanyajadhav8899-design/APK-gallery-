package com.mygallery.app

import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView

/** Image view with pinch-to-zoom, double-tap zoom and panning. */
class ZoomImageView(context: Context) : AppCompatImageView(context) {

    private val m = Matrix()
    private val vals = FloatArray(9)
    private var baseScale = 1f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val cur = currentScale()
                val target = (cur * d.scaleFactor).coerceIn(baseScale, baseScale * 6f)
                val f = target / cur
                m.postScale(f, f, d.focusX, d.focusY)
                apply()
                return true
            }
        })

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val cur = currentScale()
                val target = if (cur > baseScale * 1.01f) baseScale else baseScale * 2.5f
                val f = target / cur
                m.postScale(f, f, e.x, e.y)
                apply()
                return true
            }

            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float
            ): Boolean {
                if (currentScale() > baseScale * 1.01f) {
                    m.postTranslate(-dx, -dy)
                    apply()
                    return true
                }
                return false
            }
        })

    init {
        scaleType = ScaleType.MATRIX
    }

    override fun setImageDrawable(drawable: Drawable?) {
        super.setImageDrawable(drawable)
        fit()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fit()
    }

    private fun fit() {
        val d = drawable ?: return
        if (width == 0 || height == 0 || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return
        val s = minOf(width / d.intrinsicWidth.toFloat(), height / d.intrinsicHeight.toFloat())
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - d.intrinsicWidth * s) / 2f, (height - d.intrinsicHeight * s) / 2f)
        baseScale = s
        imageMatrix = m
    }

    private fun currentScale(): Float {
        m.getValues(vals)
        return vals[Matrix.MSCALE_X]
    }

    private fun apply() {
        val d = drawable ?: return
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        m.mapRect(r)
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2f - r.left
        else {
            if (r.left > 0) dx = -r.left
            if (r.right < width) dx = width - r.right
        }
        if (r.height() <= height) dy = (height - r.height()) / 2f - r.top
        else {
            if (r.top > 0) dy = -r.top
            if (r.bottom < height) dy = height - r.bottom
        }
        m.postTranslate(dx, dy)
        imageMatrix = m
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        val zoomed = currentScale() > baseScale * 1.01f
        parent?.requestDisallowInterceptTouchEvent(zoomed || event.pointerCount > 1)
        return true
    }
}
