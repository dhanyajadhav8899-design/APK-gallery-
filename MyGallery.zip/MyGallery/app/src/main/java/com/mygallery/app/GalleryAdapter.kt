package com.mygallery.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mygallery.app.databinding.ItemAlbumBinding
import com.mygallery.app.databinding.ItemMediaBinding

sealed class Row {
    data class Header(val text: String) : Row()
    data class Media(val item: MediaItem) : Row()
    data class AlbumRow(val album: Album) : Row()
}

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

class GalleryAdapter(
    private val onClick: (MediaItem) -> Unit,
    private val onLongClick: (MediaItem) -> Unit,
    private val onAlbumClick: (Album) -> Unit,
    private val isSelected: (MediaItem) -> Boolean
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var rows: List<Row> = emptyList()
        private set

    fun submit(newRows: List<Row>) {
        rows = newRows
        notifyDataSetChanged()
    }

    fun refreshItem(item: MediaItem) {
        val i = rows.indexOfFirst { it is Row.Media && it.item.uri == item.uri }
        if (i >= 0) notifyItemChanged(i)
    }

    fun refreshAllMedia() = notifyItemRangeChanged(0, rows.size)

    override fun getItemViewType(position: Int) = when (rows[position]) {
        is Row.Header -> 0
        is Row.Media -> 1
        is Row.AlbumRow -> 2
    }

    override fun getItemCount() = rows.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> object : RecyclerView.ViewHolder(
                inf.inflate(R.layout.item_header, parent, false)
            ) {}
            1 -> MediaHolder(ItemMediaBinding.inflate(inf, parent, false))
            else -> AlbumHolder(ItemAlbumBinding.inflate(inf, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder.itemView as TextView).text = row.text
            is Row.Media -> (holder as MediaHolder).bind(row.item)
            is Row.AlbumRow -> (holder as AlbumHolder).bind(row.album)
        }
    }

    inner class MediaHolder(private val b: ItemMediaBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: MediaItem) {
            Glide.with(b.thumb).load(item.uri).centerCrop().into(b.thumb)
            b.videoBadge.visibility = if (item.isVideo) View.VISIBLE else View.GONE
            if (item.isVideo) b.videoBadge.text = "▶ " + formatDuration(item.durationMs)
            b.selectOverlay.visibility = if (isSelected(item)) View.VISIBLE else View.GONE
            b.root.setOnClickListener { onClick(item) }
            b.root.setOnLongClickListener { onLongClick(item); true }
        }
    }

    inner class AlbumHolder(private val b: ItemAlbumBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(album: Album) {
            Glide.with(b.cover).load(album.cover.uri).centerCrop().into(b.cover)
            b.albumName.text = album.name
            b.albumCount.text = "${album.count} items"
            b.root.setOnClickListener { onAlbumClick(album) }
        }
    }
}
