package com.mygallery.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.mygallery.app.databinding.ActivityListBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Sorts recent photos into categories using Google's on-device ML Kit labeler (works offline). */
class CategoriesActivity : AppCompatActivity() {

    private lateinit var b: ActivityListBinding
    private lateinit var adapter: GalleryAdapter
    private lateinit var grid: GridLayoutManager
    private val groups = LinkedHashMap<String, MutableList<MediaItem>>()

    private companion object {
        const val LIMIT = 800

        val KEYWORDS = linkedMapOf(
            "People" to setOf("person", "selfie", "smile", "face", "crowd", "child", "baby",
                "hair", "beard", "party", "wedding", "dance", "portrait", "toddler", "bride", "groom"),
            "Food & drinks" to setOf("food", "dish", "cuisine", "meal", "fruit", "vegetable",
                "drink", "dessert", "cake", "pizza", "coffee", "breakfast", "snack", "tableware", "recipe"),
            "Pets & animals" to setOf("dog", "cat", "pet", "bird", "animal", "horse", "fish",
                "insect", "wildlife", "puppy", "kitten", "cow", "rabbit"),
            "Nature & sky" to setOf("sky", "mountain", "beach", "flower", "tree", "plant", "lake",
                "sea", "sunset", "sunrise", "cloud", "grass", "forest", "water", "river",
                "waterfall", "leaf", "garden", "sand", "snow", "rock", "ocean", "landscape", "petal"),
            "Vehicles" to setOf("car", "motorcycle", "vehicle", "bicycle", "bus", "truck", "train",
                "aircraft", "airplane", "boat", "wheel", "tire", "motor"),
            "Places & buildings" to setOf("building", "architecture", "city", "tower", "temple",
                "skyscraper", "bridge", "house", "monument", "street", "road", "castle", "palace",
                "town", "urban", "landmark"),
            "Documents & text" to setOf("text", "paper", "document", "font", "handwriting",
                "poster", "book", "receipt", "newspaper", "menu", "card"),
            "Gadgets & screens" to setOf("screen", "computer", "laptop", "phone", "display",
                "television", "electronic", "gadget", "keyboard", "technology")
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.toolbar.title = getString(R.string.menu_categories)

        grid = GridLayoutManager(this, 3)
        grid.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int) =
                if (adapter.rows.getOrNull(position) is Row.Header) 3 else 1
        }
        adapter = GalleryAdapter(
            onClick = { open(it) },
            onLongClick = {},
            onAlbumClick = {},
            isSelected = { false }
        )
        b.list.layoutManager = grid
        b.list.adapter = adapter
        classify()
    }

    private fun open(item: MediaItem) {
        val list = groups.values.firstOrNull { item in it } ?: return
        Session.items = list
        startActivity(Intent(this, ViewerActivity::class.java).putExtra("index", list.indexOf(item)))
    }

    private fun classify() {
        lifecycleScope.launch {
            b.progress.visibility = View.VISIBLE
            b.status.visibility = View.VISIBLE
            b.status.text = getString(R.string.scanning)

            val imgs = withContext(Dispatchers.IO) {
                MediaRepository.loadAll(this@CategoriesActivity).filter { !it.isVideo }.take(LIMIT)
            }
            b.progress.max = imgs.size.coerceAtLeast(1)

            val labeler = ImageLabeling.getClient(
                ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build()
            )
            withContext(Dispatchers.Default) {
                imgs.forEachIndexed { i, item ->
                    val cat = categoryOf(item, labeler)
                    synchronized(groups) { groups.getOrPut(cat) { ArrayList() }.add(item) }
                    if (i % 25 == 24) withContext(Dispatchers.Main) {
                        b.progress.progress = i + 1
                        render()
                    }
                }
            }
            labeler.close()
            b.progress.visibility = View.GONE
            b.status.text = "Sorted ${imgs.size} most recent photos"
            render()
        }
    }

    private fun categoryOf(
        item: MediaItem,
        labeler: com.google.mlkit.vision.label.ImageLabeler
    ): String {
        if (item.bucketName.contains("screenshot", true) || item.name.contains("screenshot", true))
            return "Screenshots"
        return try {
            val bmp = Glide.with(applicationContext).asBitmap().load(item.uri)
                .override(256, 256).centerCrop().submit().get()
            val labels = Tasks.await(labeler.process(InputImage.fromBitmap(bmp, 0)))
            for (label in labels) {
                val words = label.text.lowercase().split(' ', '-', '&')
                for ((cat, keys) in KEYWORDS) if (words.any { it in keys }) return cat
            }
            "Other"
        } catch (e: Exception) {
            "Other"
        }
    }

    private fun render() {
        val rows = ArrayList<Row>()
        synchronized(groups) {
            groups.entries.sortedByDescending { it.value.size }.forEach { (name, list) ->
                rows += Row.Header("$name · ${list.size}")
                list.forEach { rows += Row.Media(it) }
            }
        }
        adapter.submit(rows)
    }
}
