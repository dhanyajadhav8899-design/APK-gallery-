package com.mygallery.app

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * On-device image tools. No network, no cloud model.
 *  - inpaint(): removes painted areas by filling them from the surrounding pixels.
 *    Works best on small objects over plain or smooth backgrounds.
 *  - expand(): extends the canvas by mirroring the edges and softly blending them.
 */
object ImageOps {

    fun dilate(mask: BooleanArray, w: Int, h: Int, radius: Int): BooleanArray {
        if (radius <= 0) return mask
        var cur = mask
        repeat(radius) {
            val next = cur.copyOf()
            for (y in 0 until h) for (x in 0 until w) {
                if (cur[y * w + x]) continue
                loop@ for (dy in -1..1) for (dx in -1..1) {
                    val nx = x + dx
                    val ny = y + dy
                    if (nx in 0 until w && ny in 0 until h && cur[ny * w + nx]) {
                        next[y * w + x] = true
                        break@loop
                    }
                }
            }
            cur = next
        }
        return cur
    }

    fun inpaint(src: Bitmap, maskIn: BooleanArray): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val mask = dilate(maskIn, w, h, 2)

        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) for (x in 0 until w) if (mask[y * w + x]) {
            minX = min(minX, x); maxX = max(maxX, x)
            minY = min(minY, y); maxY = max(maxY, y)
        }
        if (maxX < 0) return src

        val pad = 3
        val x0 = max(0, minX - pad); val x1 = min(w - 1, maxX + pad)
        val y0 = max(0, minY - pad); val y1 = min(h - 1, maxY + pad)

        val unknown = mask.copyOf()
        var remaining = 0
        for (y in y0..y1) for (x in x0..x1) if (unknown[y * w + x]) remaining++

        // Peel the hole from the outside in, one ring per pass.
        var guard = 0
        while (remaining > 0 && guard++ < 5000) {
            val idx = IntArray(remaining)
            val col = IntArray(remaining)
            var n = 0
            for (y in y0..y1) for (x in x0..x1) {
                val i = y * w + x
                if (!unknown[i]) continue
                var sr = 0f; var sg = 0f; var sb = 0f; var sw = 0f
                for (dy in -2..2) for (dx in -2..2) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx
                    val ny = y + dy
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val ni = ny * w + nx
                    if (unknown[ni]) continue
                    val wt = 1f / (dx * dx + dy * dy)
                    val c = px[ni]
                    sr += ((c shr 16) and 0xFF) * wt
                    sg += ((c shr 8) and 0xFF) * wt
                    sb += (c and 0xFF) * wt
                    sw += wt
                }
                if (sw > 0f) {
                    idx[n] = i
                    col[n] = (0xFF shl 24) or
                        ((sr / sw).toInt().coerceIn(0, 255) shl 16) or
                        ((sg / sw).toInt().coerceIn(0, 255) shl 8) or
                        (sb / sw).toInt().coerceIn(0, 255)
                    n++
                }
            }
            if (n == 0) break
            for (k in 0 until n) { px[idx[k]] = col[k]; unknown[idx[k]] = false }
            remaining -= n
        }

        // Light smoothing inside the filled area so it blends with its surroundings.
        repeat(5) {
            val copy = px.copyOf()
            for (y in max(1, y0)..min(h - 2, y1)) for (x in max(1, x0)..min(w - 2, x1)) {
                val i = y * w + x
                if (!mask[i]) continue
                var r = 0; var g = 0; var bl = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val c = copy[(y + dy) * w + (x + dx)]
                    r += (c shr 16) and 0xFF
                    g += (c shr 8) and 0xFF
                    bl += c and 0xFF
                }
                px[i] = (0xFF shl 24) or ((r / 9) shl 16) or ((g / 9) shl 8) or (bl / 9)
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun reflect(i: Int, n: Int): Int {
        val period = 2 * n
        val k = ((i % period) + period) % period
        return if (k < n) k else period - 1 - k
    }

    fun expand(src: Bitmap, left: Int, top: Int, right: Int, bottom: Int): Bitmap {
        val w = src.width
        val h = src.height
        val nw = w + left + right
        val nh = h + top + bottom
        val sp = IntArray(w * h)
        src.getPixels(sp, 0, w, 0, 0, w, h)

        val out = IntArray(nw * nh)
        for (y in 0 until nh) {
            val sy = reflect(y - top, h)
            for (x in 0 until nw) out[y * nw + x] = sp[sy * w + reflect(x - left, w)]
        }

        // Blurred copy (shrink then enlarge) used to soften the new area.
        val mirrored = Bitmap.createBitmap(out, nw, nh, Bitmap.Config.ARGB_8888)
        val small = Bitmap.createScaledBitmap(mirrored, max(1, nw / 10), max(1, nh / 10), true)
        val blurredBmp = Bitmap.createScaledBitmap(small, nw, nh, true)
        val bp = IntArray(nw * nh)
        blurredBmp.getPixels(bp, 0, nw, 0, 0, nw, nh)

        val reach = max(max(left, right), max(top, bottom)) * 0.8f + 1f
        for (y in 0 until nh) for (x in 0 until nw) {
            val dx = max(max(left - x, x - (left + w - 1)), 0)
            val dy = max(max(top - y, y - (top + h - 1)), 0)
            val d = max(dx, dy)
            if (d == 0) continue
            val t = 0.35f + 0.65f * min(1f, d / reach)
            val a = out[y * nw + x]
            val b = bp[y * nw + x]
            val r = (((a shr 16) and 0xFF) * (1 - t) + ((b shr 16) and 0xFF) * t).toInt()
            val g = (((a shr 8) and 0xFF) * (1 - t) + ((b shr 8) and 0xFF) * t).toInt()
            val bl = ((a and 0xFF) * (1 - t) + (b and 0xFF) * t).toInt()
            out[y * nw + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
        if (mirrored !== blurredBmp) { small.recycle(); blurredBmp.recycle() }
        return Bitmap.createBitmap(out, nw, nh, Bitmap.Config.ARGB_8888)
    }
}
