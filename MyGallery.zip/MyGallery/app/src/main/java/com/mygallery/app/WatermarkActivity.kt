package com.mygallery.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.mygallery.app.databinding.ActivityWatermarkBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot

/**
 * Stamps a repeating diagonal text (purpose + date) over a photo of an ID or document,
 * so a copy that leaks cannot easily be reused for something else. Saved as a new copy.
 */
class WatermarkActivity : AppCompatActivity() {

    private lateinit var b: ActivityWatermarkBinding
    private var base: Bitmap? = null
    private var result: Bitmap? = null
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityWatermarkBinding.inflate(layoutInflater)
        setContentView(b.root)

        val uri = intent.data
        if (uri == null) { finish(); return }

        lifecycleScope.launch {
            base = withContext(Dispatchers.IO) {
                try {
                    Glide.with(applicationContext).asBitmap().load(uri)
                        .override(2560, 2560).fitCenter().submit().get()
                } catch (e: Exception) { null }
            }
            if (base == null) {
                Toast.makeText(this@WatermarkActivity, "Could not open this photo", Toast.LENGTH_SHORT).show()
                finish()
            } else render()
        }

        b.wmText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = render()
        })
        b.opacitySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = render()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        b.addDate.setOnCheckedChangeListener { _, _ -> render() }
        b.btnSaveWm.setOnClickListener { save() }
    }

    private fun render() {
        val src = base ?: return
        val text = b.wmText.text.toString().trim().ifEmpty { "For verification only" }
        val withDate = b.addDate.isChecked
        val opacity = b.opacitySeek.progress.coerceIn(5, 100)
        job?.cancel()
        job = lifecycleScope.launch {
            val out = withContext(Dispatchers.Default) { stamp(src, text, withDate, opacity) }
            result = out
            b.preview.setImageBitmap(out)
        }
    }

    private fun stamp(src: Bitmap, text: String, withDate: Boolean, opacity: Int): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val label = if (withDate)
            text + "  •  " + SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date())
        else text

        val size = w / 20f
        val alpha = (opacity * 255 / 100)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            this.alpha = alpha
            textSize = size
            typeface = Typeface.DEFAULT_BOLD
        }
        val outline = Paint(fill).apply {
            color = Color.BLACK
            this.alpha = alpha
            style = Paint.Style.STROKE
            strokeWidth = size / 9f
        }

        val c = Canvas(bmp)
        c.save()
        c.rotate(-30f, w / 2f, h / 2f)
        val stepX = fill.measureText(label) + size * 2f
        val stepY = size * 3.2f
        val diag = hypot(w, h)
        var row = 0
        var y = h / 2f - diag
        while (y < h / 2f + diag) {
            val shift = if (row % 2 == 0) 0f else stepX / 2f
            var x = w / 2f - diag - shift
            while (x < w / 2f + diag) {
                c.drawText(label, x, y, outline)
                c.drawText(label, x, y, fill)
                x += stepX
            }
            y += stepY
            row++
        }
        c.restore()
        return bmp
    }

    private fun save() {
        val bmp = result ?: return
        lifecycleScope.launch {
            val uri = withContext(Dispatchers.IO) { ImageSaver.save(this@WatermarkActivity, bmp, "watermarked") }
            Toast.makeText(
                this@WatermarkActivity,
                if (uri != null) getString(R.string.saved) else "Could not save",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
