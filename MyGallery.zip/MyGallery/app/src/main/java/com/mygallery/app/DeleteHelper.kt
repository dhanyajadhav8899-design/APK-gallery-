package com.mygallery.app

import android.app.Activity
import android.app.RecoverableSecurityException
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Deletes media in a way that works on every Android version:
 *  - Android 11+  : system confirmation dialog (createDeleteRequest)
 *  - Android 10   : handles RecoverableSecurityException
 *  - Android 9-   : direct delete (needs storage permission)
 * Create it as a field of the activity so it registers before the activity starts.
 */
class DeleteHelper(
    private val activity: ComponentActivity,
    private val onDone: () -> Unit
) {
    private var pending: MutableList<Uri> = mutableListOf()

    private val launcher = activity.registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) onDone() else deleteLegacy()
        }
    }

    fun delete(uris: List<Uri>) {
        if (uris.isEmpty()) return
        pending = uris.toMutableList()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val sender = MediaStore.createDeleteRequest(activity.contentResolver, uris).intentSender
            launcher.launch(IntentSenderRequest.Builder(sender).build())
        } else {
            deleteLegacy()
        }
    }

    private fun deleteLegacy() {
        while (pending.isNotEmpty()) {
            val u = pending.first()
            try {
                activity.contentResolver.delete(u, null, null)
                pending.removeAt(0)
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && e is RecoverableSecurityException) {
                    launcher.launch(
                        IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build()
                    )
                    return
                }
                pending.removeAt(0)
            }
        }
        onDone()
    }
}
