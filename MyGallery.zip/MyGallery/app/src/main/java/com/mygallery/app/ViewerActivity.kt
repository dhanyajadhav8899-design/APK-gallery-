package com.mygallery.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.exifinterface.media.ExifInterface
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mygallery.app.databinding.ActivityViewerBinding
import java.text.DateFormat
import java.util.Date

class ViewerActivity : AppCompatActivity() {

    private lateinit var b: ActivityViewerBinding
    private val items = Session.items.toMutableList()
    private lateinit var pagerAdapter: PagerAdapter
    private var deleting: MediaItem? = null

    private val deleter = DeleteHelper(this) {
        deleting?.let { items.remove(it) }
        Session.items = items
        if (items.isEmpty()) finish() else pagerAdapter.notifyDataSetChanged()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (items.isEmpty()) { finish(); return }
        b = ActivityViewerBinding.inflate(layoutInflater)
        setContentView(b.root)

        pagerAdapter = PagerAdapter(items) { playVideo(it) }
        b.pager.adapter = pagerAdapter
        b.pager.setCurrentItem(intent.getIntExtra("index", 0).coerceIn(0, items.lastIndex), false)

        b.btnShare.setOnClickListener { share(current()) }
        b.btnDelete.setOnClickListener { deleting = current(); deleter.delete(listOf(current().uri)) }
        b.btnInfo.setOnClickListener { showInfo(current()) }
        b.btnEdit.setOnClickListener { openTool(EditorActivity::class.java) }
        b.btnWatermark.setOnClickListener { openTool(WatermarkActivity::class.java) }
    }

    private fun current() = items[b.pager.currentItem]

    private fun openTool(cls: Class<*>) {
        val item = current()
        if (item.isVideo) {
            Toast.makeText(this, "This tool works on photos only", Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(Intent(this, cls).setData(item.uri))
    }

    private fun share(item: MediaItem) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = item.mime.ifEmpty { "*/*" }
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share)))
    }

    private fun playVideo(item: MediaItem) {
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(item.uri, item.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(intent)
    }

    private fun showInfo(item: MediaItem) {
        val sb = StringBuilder()
        sb.append("Name: ").append(item.name).append('\n')
        sb.append("Date: ").append(DateFormat.getDateTimeInstance().format(Date(item.timeMillis))).append('\n')
        sb.append("Size: ").append(Formatter.formatFileSize(this, item.size)).append('\n')
        if (item.width > 0) sb.append("Resolution: ${item.width} x ${item.height}\n")
        sb.append("Folder: ").append(item.bucketName).append('\n')
        if (item.isVideo) sb.append("Length: ").append(formatDuration(item.durationMs)).append('\n')
        else {
            try {
                contentResolver.openInputStream(item.uri)?.use { s ->
                    val ll = ExifInterface(s).latLong
                    if (ll != null) sb.append("Location: %.5f, %.5f".format(ll[0], ll[1]))
                }
            } catch (_: Exception) { }
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.info)
            .setMessage(sb.toString().trim())
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private class PagerAdapter(
        private val items: List<MediaItem>,
        private val onVideoClick: (MediaItem) -> Unit
    ) : RecyclerView.Adapter<PagerAdapter.VH>() {

        class VH(root: FrameLayout, val zoom: ZoomImageView, val play: TextView) :
            RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val root = FrameLayout(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            val zoom = ZoomImageView(ctx)
            root.addView(
                zoom,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            val play = TextView(ctx).apply {
                text = "▶"
                textSize = 56f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
            }
            root.addView(
                play,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
            return VH(root, zoom, play)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            Glide.with(holder.zoom).load(item.uri).override(2048, 2048).fitCenter().into(holder.zoom)
            holder.play.visibility = if (item.isVideo) android.view.View.VISIBLE else android.view.View.GONE
            holder.play.setOnClickListener { onVideoClick(item) }
        }

        override fun getItemCount() = items.size
    }
}
