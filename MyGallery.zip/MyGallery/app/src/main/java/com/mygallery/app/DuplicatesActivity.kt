package com.mygallery.app

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mygallery.app.databinding.ActivityListBinding
import com.mygallery.app.databinding.ItemDupBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

/** Finds photos that look the same (perceptual hash) and lets you delete the extras. */
class DuplicatesActivity : AppCompatActivity() {

    sealed class DupRow {
        data class Header(val text: String) : DupRow()
        class Item(val media: MediaItem, var checked: Boolean) : DupRow()
    }

    private lateinit var b: ActivityListBinding
    private val rows = ArrayList<DupRow>()
    private lateinit var adapter: DupAdapter
    private val deleter = DeleteHelper(this) { scan() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityListBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.toolbar.title = getString(R.string.menu_duplicates)

        adapter = DupAdapter(rows) { updateButton() }
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.actionBtn.setOnClickListener {
            deleter.delete(rows.filterIsInstance<DupRow.Item>().filter { it.checked }.map { it.media.uri })
        }
        scan()
    }

    private fun scan() {
        lifecycleScope.launch {
            b.progress.visibility = View.VISIBLE
            b.status.visibility = View.VISIBLE
            b.status.text = getString(R.string.scanning)
            b.actionBtn.visibility = View.GONE
            rows.clear()
            adapter.notifyDataSetChanged()

            val imgs = withContext(Dispatchers.IO) {
                MediaRepository.loadAll(this@DuplicatesActivity).filter { !it.isVideo }.take(8000)
            }
            val n = imgs.size
            b.progress.max = n.coerceAtLeast(1)
            val hashes = LongArray(n)
            val ok = BooleanArray(n)
            val counter = AtomicInteger()
            val workers = 4

            withContext(Dispatchers.Default) {
                (0 until workers).map { w ->
                    async {
                        var i = w
                        while (i < n) {
                            try { hashes[i] = dHash(imgs[i].uri); ok[i] = true } catch (_: Exception) {}
                            val done = counter.incrementAndGet()
                            if (done % 25 == 0) withContext(Dispatchers.Main) { b.progress.progress = done }
                            i += workers
                        }
                    }
                }.awaitAll()
            }

            val groups = withContext(Dispatchers.Default) { group(imgs, hashes, ok) }

            var gi = 1
            var freeable = 0L
            for (g in groups) {
                val sorted = g.sortedWith(compareByDescending<MediaItem> { it.size }.thenBy { it.timeMillis })
                rows += DupRow.Header("Group $gi · ${sorted.size} similar photos")
                sorted.forEachIndexed { idx, m ->
                    rows += DupRow.Item(m, checked = idx > 0)
                    if (idx > 0) freeable += m.size
                }
                gi++
            }
            b.progress.visibility = View.GONE
            b.status.text = if (groups.isEmpty()) getString(R.string.no_duplicates)
            else "${groups.size} groups found · up to ${Formatter.formatFileSize(this@DuplicatesActivity, freeable)} can be freed. " +
                "The largest photo in each group is kept."
            adapter.notifyDataSetChanged()
            updateButton()
        }
    }

    private fun dHash(uri: Uri): Long {
        val bmp = Glide.with(applicationContext).asBitmap().load(uri)
            .override(64, 64).centerCrop().submit().get()
        val small = Bitmap.createScaledBitmap(bmp, 9, 8, true)
        var hash = 0L
        for (y in 0 until 8) for (x in 0 until 8) {
            val l = gray(small.getPixel(x, y))
            val r = gray(small.getPixel(x + 1, y))
            hash = (hash shl 1) or (if (l > r) 1L else 0L)
        }
        return hash
    }

    private fun gray(c: Int) = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10

    private fun group(imgs: List<MediaItem>, hashes: LongArray, ok: BooleanArray): List<List<MediaItem>> {
        val n = imgs.size
        val parent = IntArray(n) { it }
        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) r = parent[r]
            var c = x
            while (parent[c] != r) { val nx = parent[c]; parent[c] = r; c = nx }
            return r
        }
        fun ratio(m: MediaItem) = if (m.height > 0) m.width / m.height.toFloat() else 1f
        for (i in 0 until n) {
            if (!ok[i]) continue
            for (j in i + 1 until n) {
                if (!ok[j]) continue
                if (java.lang.Long.bitCount(hashes[i] xor hashes[j]) <= 3 &&
                    abs(ratio(imgs[i]) - ratio(imgs[j])) < 0.05f
                ) {
                    val a = find(i); val c = find(j)
                    if (a != c) parent[a] = c
                }
            }
        }
        return (0 until n).filter { ok[it] }.groupBy { find(it) }.values
            .filter { it.size >= 2 }
            .map { idxs -> idxs.map { imgs[it] } }
    }

    private fun updateButton() {
        val count = rows.count { it is DupRow.Item && it.checked }
        b.actionBtn.visibility = if (count > 0) View.VISIBLE else View.GONE
        b.actionBtn.text = "${getString(R.string.delete_selected)} ($count)"
    }

    private class DupAdapter(
        private val rows: List<DupRow>,
        private val onChanged: () -> Unit
    ) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun getItemViewType(position: Int) = if (rows[position] is DupRow.Header) 0 else 1
        override fun getItemCount() = rows.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val inf = LayoutInflater.from(parent.context)
            return if (viewType == 0)
                object : RecyclerView.ViewHolder(inf.inflate(R.layout.item_header, parent, false)) {}
            else ItemHolder(ItemDupBinding.inflate(inf, parent, false))
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val row = rows[position]) {
                is DupRow.Header -> (holder.itemView as TextView).text = row.text
                is DupRow.Item -> (holder as ItemHolder).bind(row)
            }
        }

        inner class ItemHolder(private val v: ItemDupBinding) : RecyclerView.ViewHolder(v.root) {
            fun bind(row: DupRow.Item) {
                val m = row.media
                Glide.with(v.thumb).load(m.uri).centerCrop().into(v.thumb)
                v.dupName.text = m.name
                v.dupInfo.text = "${Formatter.formatFileSize(v.root.context, m.size)} · ${m.width}x${m.height} · ${m.bucketName}"
                v.dupCheck.setOnCheckedChangeListener(null)
                v.dupCheck.isChecked = row.checked
                v.dupCheck.setOnCheckedChangeListener { _, checked -> row.checked = checked; onChanged() }
                v.root.setOnClickListener { v.dupCheck.toggle() }
            }
        }
    }
}
