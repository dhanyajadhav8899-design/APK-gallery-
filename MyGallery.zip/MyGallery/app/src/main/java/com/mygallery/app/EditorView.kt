package com.mygallery.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** Shows a photo and lets the user paint over the area they want erased. */
class EditorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var paintEnabled = true
    var brushScreenPx = 40f

    private var bitmap: Bitmap? = null
    private var maskBmp: Bitmap? = null
    private var maskCanvas: Canvas? = null
    private var hasMask = false

    private val dest = RectF()
    private var scale = 1f

    private val overlayPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(Color.argb(150, 255, 40, 70), PorterDuff.Mode.SRC_IN)
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    private var lastX = 0f
    private var lastY = 0f

    fun setImage(bmp: Bitmap) {
        bitmap = bmp
        maskBmp = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        maskCanvas = Canvas(maskBmp!!)
        hasMask = false
        computeDest()
        invalidate()
    }

    fun clearMask() {
        maskBmp?.eraseColor(Color.TRANSPARENT)
        hasMask = false
        invalidate()
    }

    fun hasMask() = hasMask

    /** True where the user painted. */
    fun getMask(): BooleanArray? {
        val m = maskBmp ?: return null
        if (!hasMask) return null
        val w = m.width
        val h = m.height
        val px = IntArray(w * h)
        m.getPixels(px, 0, w, 0, 0, w, h)
        return BooleanArray(w * h) { (px[it] ushr 24) > 40 }
    }

    private fun computeDest() {
        val bmp = bitmap ?: return
        if (width == 0 || height == 0) return
        scale = minOf(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        val dw = bmp.width * scale
        val dh = bmp.height * scale
        val l = (width - dw) / 2f
        val t = (height - dh) / 2f
        dest.set(l, t, l + dw, t + dh)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeDest()
    }

    override fun onDraw(canvas: Canvas) {
        val bmp = bitmap ?: return
        canvas.drawBitmap(bmp, null, dest, bitmapPaint)
        maskBmp?.let { if (hasMask) canvas.drawBitmap(it, null, dest, overlayPaint) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!paintEnabled || bitmap == null) return false
        val x = (event.x - dest.left) / scale
        val y = (event.y - dest.top) / scale
        val brush = brushScreenPx / scale
        val c = maskCanvas ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                c.drawCircle(x, y, brush / 2f, dotPaint)
                lastX = x; lastY = y
                hasMask = true
            }
            MotionEvent.ACTION_MOVE -> {
                strokePaint.strokeWidth = brush
                c.drawLine(lastX, lastY, x, y, strokePaint)
                lastX = x; lastY = y
            }
        }
        invalidate()
        return true
    }
}
