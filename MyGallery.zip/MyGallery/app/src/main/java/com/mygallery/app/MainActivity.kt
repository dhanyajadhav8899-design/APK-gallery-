package com.mygallery.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mygallery.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Hands the current list to the viewer without parcelling thousands of items. */
object Session {
    var items: List<MediaItem> = emptyList()
}

class MainActivity : AppCompatActivity() {

    private enum class Tab { ALL, QUICK, ALBUMS }

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: GalleryAdapter
    private lateinit var layoutManager: GridLayoutManager

    private var all: List<MediaItem> = emptyList()
    private var tab = Tab.ALL
    private var openedAlbum: Album? = null
    private var currentList: List<MediaItem> = emptyList()
    private val selected = LinkedHashSet<MediaItem>()
    private var span = 3

    private val prefs by lazy { getSharedPreferences("gallery", MODE_PRIVATE) }

    private val deleter = DeleteHelper(this) {
        selected.clear()
        updateSelectionUi()
        reload()
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            checkPermissionAndLoad()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        span = prefs.getInt("span", 3)
        setupToolbar()
        setupGrid()
        setupBottomNav()

        b.selShare.setOnClickListener { shareSelected() }
        b.selDelete.setOnClickListener { deleter.delete(selected.map { it.uri }) }
        b.grantButton.setOnClickListener { requestPermissions() }
        if (!hasPermission()) requestPermissions()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    selected.isNotEmpty() -> {
                        selected.clear(); updateSelectionUi(); adapter.refreshAllMedia()
                    }
                    openedAlbum != null -> { openedAlbum = null; render() }
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        checkPermissionAndLoad()
        refreshQuickTabTitle()
    }

    // ---------- setup ----------

    private fun setupToolbar() {
        b.toolbar.inflateMenu(R.menu.main_menu)
        b.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_categories -> startActivity(Intent(this, CategoriesActivity::class.java))
                R.id.action_duplicates -> startActivity(Intent(this, DuplicatesActivity::class.java))
                R.id.action_pin -> pinCurrentAlbum()
            }
            true
        }
    }

    private fun setupGrid() {
        layoutManager = GridLayoutManager(this, span)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                val row = adapter.rows.getOrNull(position)
                return if (row is Row.Header) layoutManager.spanCount else 1
            }
        }
        adapter = GalleryAdapter(
            onClick = { item -> onItemClick(item) },
            onLongClick = { item -> toggleSelect(item) },
            onAlbumClick = { album -> openedAlbum = album; render() },
            isSelected = { it in selected }
        )
        b.recycler.layoutManager = layoutManager
        b.recycler.adapter = adapter

        // Pinch-to-zoom changes how many thumbnails per row (2..7)
        val detector = ScaleGestureDetector(this, object :
            ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var acc = 1f
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { acc = 1f; return true }
            override fun onScale(d: ScaleGestureDetector): Boolean {
                if (tab == Tab.ALBUMS && openedAlbum == null) return true
                acc *= d.scaleFactor
                if (acc > 1.25f) { setSpan(span - 1); acc = 1f }
                else if (acc < 0.8f) { setSpan(span + 1); acc = 1f }
                return true
            }
        })
        b.recycler.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                detector.onTouchEvent(e)
                return e.pointerCount > 1
            }
            override fun onTouchEvent(rv: RecyclerView, e: MotionEvent) {
                detector.onTouchEvent(e)
            }
        })
    }

    private fun setSpan(n: Int) {
        val v = n.coerceIn(2, 7)
        if (v == span) return
        span = v
        layoutManager.spanCount = v
        prefs.edit().putInt("span", v).apply()
    }

    private fun setupBottomNav() {
        b.bottomNav.setOnItemSelectedListener { item ->
            tab = when (item.itemId) {
                R.id.nav_camera -> Tab.QUICK
                R.id.nav_albums -> Tab.ALBUMS
                else -> Tab.ALL
            }
            openedAlbum = null
            selected.clear()
            updateSelectionUi()
            render()
            true
        }
    }

    // ---------- permissions + data ----------

    private fun neededPermissions(): Array<String> = when {
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO
        )
        Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        else -> arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE
        )
    }

    private fun hasPermission() = neededPermissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() = permLauncher.launch(neededPermissions())

    private fun checkPermissionAndLoad() {
        if (hasPermission()) {
            b.permissionBox.visibility = View.GONE
            reload()
        } else {
            b.permissionBox.visibility = View.VISIBLE
        }
    }

    private fun reload() {
        lifecycleScope.launch {
            all = withContext(Dispatchers.IO) { MediaRepository.loadAll(this@MainActivity) }
            render()
        }
    }

    // ---------- rendering ----------

    private fun quickSource(): List<MediaItem> {
        val pinned = prefs.getLong("pinned_id", -1L)
        return if (pinned != -1L) all.filter { it.bucketId == pinned }
        else all.filter { it.bucketName.equals("Camera", ignoreCase = true) }
    }

    private fun refreshQuickTabTitle() {
        val name = prefs.getString("pinned_name", null) ?: getString(R.string.tab_camera)
        b.bottomNav.menu.findItem(R.id.nav_camera).title = name
    }

    private fun render() {
        val rows = ArrayList<Row>()
        when {
            tab == Tab.ALBUMS && openedAlbum == null -> {
                layoutManager.spanCount = 2
                MediaRepository.albums(all).forEach { rows += Row.AlbumRow(it) }
                currentList = emptyList()
                b.toolbar.title = getString(R.string.tab_albums)
                b.toolbar.navigationIcon = null
            }
            else -> {
                layoutManager.spanCount = span
                val source = when {
                    openedAlbum != null -> all.filter { it.bucketId == openedAlbum!!.bucketId }
                    tab == Tab.QUICK -> quickSource()
                    else -> all
                }
                currentList = source
                rows += buildDateRows(source)
                b.toolbar.title = openedAlbum?.name ?: when (tab) {
                    Tab.QUICK -> prefs.getString("pinned_name", null) ?: getString(R.string.tab_camera)
                    else -> getString(R.string.app_name)
                }
            }
        }
        adapter.submit(rows)
    }

    private fun buildDateRows(items: List<MediaItem>): List<Row> {
        val fmt = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault())
        val out = ArrayList<Row>()
        var last = ""
        for (it in items) {
            val day = fmt.format(Date(it.timeMillis))
            if (day != last) { out += Row.Header(day); last = day }
            out += Row.Media(it)
        }
        return out
    }

    // ---------- interactions ----------

    private fun onItemClick(item: MediaItem) {
        if (selected.isNotEmpty()) { toggleSelect(item); return }
        Session.items = currentList
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .putExtra("index", currentList.indexOf(item).coerceAtLeast(0))
        )
    }

    private fun toggleSelect(item: MediaItem) {
        if (!selected.add(item)) selected.remove(item)
        updateSelectionUi()
        adapter.refreshItem(item)
    }

    private fun updateSelectionUi() {
        b.selectionBar.visibility = if (selected.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun shareSelected() {
        val uris = ArrayList(selected.map { it.uri })
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share)))
    }

    private fun pinCurrentAlbum() {
        val album = openedAlbum
        if (album == null) {
            Toast.makeText(this, "Open an album first, then pin it.", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.edit().putLong("pinned_id", album.bucketId).putString("pinned_name", album.name).apply()
        refreshQuickTabTitle()
        Toast.makeText(this, "\"${album.name}\" is now your quick tab", Toast.LENGTH_SHORT).show()
    }
}
