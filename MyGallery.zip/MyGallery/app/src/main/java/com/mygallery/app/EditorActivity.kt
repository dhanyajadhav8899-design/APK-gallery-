package com.mygallery.app

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.mygallery.app.databinding.ActivityEditorBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Erase objects (paint over them) and expand the picture. Saves as a new copy. */
class EditorActivity : AppCompatActivity() {

    private lateinit var b: ActivityEditorBinding
    private var current: Bitmap? = null
    private val history = ArrayDeque<Bitmap>()
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(b.root)

        val uri = intent.data
        if (uri == null) { finish(); return }

        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try {
                    Glide.with(applicationContext).asBitmap().load(uri)
                        .override(2560, 2560).fitCenter().submit().get()
                        .copy(Bitmap.Config.ARGB_8888, true)
                } catch (e: Exception) { null }
            }
            if (bmp == null) {
                Toast.makeText(this@EditorActivity, "Could not open this photo", Toast.LENGTH_SHORT).show()
                finish()
            } else setBitmap(bmp)
        }

        updateBrush(b.brushSeek.progress)
        b.brushSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = updateBrush(p)
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        b.modeErase.setOnClickListener { setMode(erase = true) }
        b.modeExpand.setOnClickListener { setMode(erase = false) }
        b.btnApplyErase.setOnClickListener { applyErase() }
        b.btnExpandWide.setOnClickListener { expand(0.15f, 0f) }
        b.btnExpandTall.setOnClickListener { expand(0f, 0.15f) }
        b.btnExpandAll.setOnClickListener { expand(0.12f, 0.12f) }
        b.btnUndo.setOnClickListener { undo() }
        b.btnSave.setOnClickListener { save() }
    }

    private fun setBitmap(bmp: Bitmap) {
        current = bmp
        b.editorView.setImage(bmp)
    }

    private fun updateBrush(progress: Int) {
        b.editorView.brushScreenPx = 12f + progress * 2.2f
    }

    private fun setMode(erase: Boolean) {
        b.editorView.paintEnabled = erase
        b.eraseControls.visibility = if (erase) View.VISIBLE else View.GONE
        b.expandControls.visibility = if (erase) View.GONE else View.VISIBLE
    }

    private fun applyErase() {
        val bmp = current ?: return
        val mask = b.editorView.getMask()
        if (mask == null) {
            Toast.makeText(this, "Paint over what you want to remove first", Toast.LENGTH_SHORT).show()
            return
        }
        runWork {
            val result = withContext(Dispatchers.Default) { ImageOps.inpaint(bmp, mask) }
            push(bmp)
            setBitmap(result)
        }
    }

    private fun expand(fx: Float, fy: Float) {
        val bmp = current ?: return
        val dx = (bmp.width * fx).toInt()
        val dy = (bmp.height * fy).toInt()
        if (bmp.width + 2 * dx > 4096 || bmp.height + 2 * dy > 4096) {
            Toast.makeText(this, "Image is already at the size limit", Toast.LENGTH_SHORT).show()
            return
        }
        runWork {
            val result = withContext(Dispatchers.Default) { ImageOps.expand(bmp, dx, dy, dx, dy) }
            push(bmp)
            setBitmap(result)
        }
    }

    private fun push(bmp: Bitmap) {
        history.addLast(bmp)
        if (history.size > 5) history.removeFirst()
    }

    private fun undo() {
        val prev = history.removeLastOrNull() ?: return
        setBitmap(prev)
    }

    private fun save() {
        val bmp = current ?: return
        runWork {
            val uri = withContext(Dispatchers.IO) { ImageSaver.save(this@EditorActivity, bmp, "edited") }
            Toast.makeText(
                this@EditorActivity,
                if (uri != null) getString(R.string.saved) else "Could not save",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun runWork(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        Toast.makeText(this, R.string.working, Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            try { block() } finally { busy = false }
        }
    }
}
