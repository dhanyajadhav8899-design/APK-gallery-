# My Gallery

An original gallery app (package `com.mygallery.app`). It installs next to your stock
gallery and does not replace it. Runs on Android 7.0 (API 24) and newer.
No Xiaomi code or services are used.

## Get the APK (no Android Studio needed)

1. Create a free GitHub account and a new empty repository.
2. Upload every file from this folder (keep the folder structure, including `.github`).
3. Open the **Actions** tab, run **Build APK** (it also runs on every push).
4. When it finishes (about 5 minutes), open the run and download **MyGallery-APK**.
5. Unzip it, copy `app-debug.apk` to your phone, tap it, and allow "Install unknown apps".

Or open this folder in Android Studio and press Run.

## Features

- Photos and videos grouped by date, plus an Albums tab
- Bottom bar: **All** / quick tab (Camera by default) / **Albums**.
  Open any album, then menu > "Pin current album as quick tab" to change the middle tab
- Pinch the grid to change thumbnail size (2 to 7 per row)
- Viewer with pinch zoom, double-tap zoom, swipe, share, delete, info (date, size, GPS)
- Long-press to multi-select, then share or delete
- **AI Erase** (paint over an object) and **Expand** (extend the picture's edges).
  These run on the phone with no cloud model, so they are simpler than Xiaomi's HyperAI:
  Erase works best on small objects over plain backgrounds, and Expand mirrors and
  blends the edges rather than inventing new content.
- **Privacy watermark**: tiles your text plus today's date across an ID or document
  photo and saves a copy
- **Smart categories**: sorts your 800 most recent photos (People, Food, Pets, Nature,
  Vehicles, Places, Documents, Screenshots...) with Google's on-device ML Kit
- **Find duplicates**: spots look-alike photos, keeps the largest, deletes the rest

Edited and watermarked photos are saved as new files in Pictures/MyGallery.
Your originals are never changed.
